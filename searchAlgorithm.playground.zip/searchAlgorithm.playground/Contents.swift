//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var people = ["yuhi","minami","yuko"]

func search(names: [String], with capitalletter: String) -> [String] {
    var searchedNames = [String]()
    for name in people {
        if name .hasPrefix(capitalletter) {
            searchedNames.append(name)

        } else {
            print(name, " does not start with ",  capitalletter)
        }
    }
    return searchedNames
}


search(names: people, with: "y")



